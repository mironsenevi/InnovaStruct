import React from 'react'
import ClientNavbar from '../../components/ClientNavbar'

const Home = () => {
  return (
    <div>
        <ClientNavbar />
    </div>
  )
}

export default Home